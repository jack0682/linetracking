#!/usr/bin/env python3

import numpy as np
from typing import Dict, Any, Optional
import cvxpy as cp

class CBFSafetyFilter:
    def __init__(self, params: Dict[str, Any]):
        self.safety_params = params["track"]["safety_margins"]
        self.alpha = 1.0  # α-class K function parameter
        
    def compute_barrier_functions(self, state: Dict[str, float]) -> Dict[str, float]:
        """
        Compute barrier functions:
        h1(x) = d_max - |d|        (lateral safety)
        h2(x) = d_free - d_min     (forward collision avoidance)
        """
        d = state["lateral_deviation"]
        d_free = state["lidar_front"]
        
        h1 = self.safety_params["d_max"] - abs(d)
        h2 = d_free - self.safety_params["d_free_critical"]
        
        return {"lateral_safety": h1, "collision_avoidance": h2}
        
    def compute_barrier_derivatives(self, state: Dict[str, float], action: np.ndarray) -> Dict[str, float]:
        """
        Compute Lie derivatives ḣᵢ for barrier functions
        """
        d = state["lateral_deviation"]
        v = action[0]  # linear velocity
        omega = action[1]  # angular velocity
        
        # Simplified dynamics: ḋ ≈ v * sin(Δψ), d_free decreases with forward motion
        sin_heading_error = np.sin(state["heading_error"])
        
        h1_dot = -np.sign(d) * v * sin_heading_error  # lateral barrier derivative
        h2_dot = -v  # forward barrier derivative (approaching obstacle)
        
        return {"lateral_safety_dot": h1_dot, "collision_avoidance_dot": h2_dot}
        
    def apply_cbf_filter(self, rl_action: np.ndarray, state: Dict[str, float]) -> np.ndarray:
        """
        Apply CBF filtering via QP: min ||u_safe - u_rl||² s.t. ḣᵢ + αhᵢ ≥ 0
        """
        try:
            return self._solve_cbf_qp(rl_action, state)
        except:
            # Fallback to simple action masking if QP fails
            return self._apply_action_masking(rl_action, state)
            
    def _solve_cbf_qp(self, rl_action: np.ndarray, state: Dict[str, float]) -> np.ndarray:
        """Solve CBF QP optimization problem"""
        u = cp.Variable(2)  # [v, ω]
        
        # Objective: minimize ||u - u_rl||²
        objective = cp.Minimize(cp.sum_squares(u - rl_action))
        
        # CBF constraints: ḣᵢ + αhᵢ ≥ 0
        h_vals = self.compute_barrier_functions(state)
        constraints = []
        
        # Lateral safety constraint
        if h_vals["lateral_safety"] < 0.1:  # Only activate near boundary
            d = state["lateral_deviation"]
            sin_heading = np.sin(state["heading_error"])
            h1_dot = -np.sign(d) * u[0] * sin_heading
            constraints.append(h1_dot + self.alpha * h_vals["lateral_safety"] >= 0)
            
        # Forward collision constraint  
        if h_vals["collision_avoidance"] < 0.5:  # Only activate when close
            h2_dot = -u[0]  # forward motion decreases d_free
            constraints.append(h2_dot + self.alpha * h_vals["collision_avoidance"] >= 0)
            
        # Action bounds
        constraints.extend([
            u[0] >= 0.0,     # v ≥ 0
            u[0] <= 0.25,    # v ≤ 0.25
            u[1] >= -1.2,    # ω ≥ -1.2  
            u[1] <= 1.2      # ω ≤ 1.2
        ])
        
        prob = cp.Problem(objective, constraints)
        prob.solve(solver=cp.OSQP, verbose=False)
        
        if prob.status != cp.OPTIMAL:
            raise RuntimeError("QP solver failed")
            
        return np.array([u[0].value, u[1].value])
        
    def _apply_action_masking(self, rl_action: np.ndarray, state: Dict[str, float]) -> np.ndarray:
        """
        Fallback action masking for real-world deployment:
        - d_free < 0.35m ⇒ v ≤ 0.05
        - |d| > 0.18m ⇒ |ω| ≥ 0.2 (corrective steering)
        """
        v, omega = rl_action.copy()
        d_free = state["lidar_front"]
        d = abs(state["lateral_deviation"])
        
        # Forward collision masking
        if d_free < 0.35:
            v = min(v, 0.05)
            
        # Lateral deviation masking
        if d > 0.18:
            if abs(omega) < 0.2:
                omega = 0.2 * np.sign(state["lateral_deviation"])  # Correct toward center
                
        # Ensure bounds
        v = np.clip(v, 0.0, 0.25)
        omega = np.clip(omega, -1.2, 1.2)
        
        return np.array([v, omega])
        
    def is_safe_state(self, state: Dict[str, float]) -> bool:
        """Check if current state satisfies all safety constraints"""
        h_vals = self.compute_barrier_functions(state)
        return all(h > 0 for h in h_vals.values())