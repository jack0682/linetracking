#!/usr/bin/env python3

import numpy as np
from typing import Dict, Any
from enum import Enum

class OptionMode(Enum):
    DRIVING = "driving"
    MANIPULATOR = "manipulator"

class OptionManager:
    def __init__(self, params: Dict[str, Any]):
        self.safety_params = params["track"]["safety_margins"]
        self.detection_params = params["track"]["detection"]
        
        # Option switch thresholds from your specification
        self.d_free_threshold = 0.5  # meters
        self.q_threshold = self.detection_params["lane_confidence_threshold"]  # q0
        
        self.current_mode = OptionMode.DRIVING
        self.mode_switch_cooldown = 0
        self.cooldown_frames = 30  # prevent rapid switching
        
    def should_switch_to_manipulator(self, state: Dict[str, float]) -> bool:
        """
        Switch condition: (d_free < 0.5 ∧ q > q0)
        Only switch to manipulator when close to obstacle AND confident in lane detection
        """
        d_free = state["lidar_front"] 
        q = state["lane_confidence"]
        
        return (d_free < self.d_free_threshold and 
                q > self.q_threshold and 
                self.mode_switch_cooldown <= 0)
                
    def should_switch_to_driving(self, state: Dict[str, float]) -> bool:
        """
        Switch back to driving when obstacle cleared or lane confidence low
        """
        d_free = state["lidar_front"]
        q = state["lane_confidence"]
        
        return (d_free > self.d_free_threshold + 0.1 or  # hysteresis
                q < self.q_threshold - 0.1)
                
    def update_option(self, state: Dict[str, float]) -> OptionMode:
        """
        Rule-based option switching (no learning for Day 7)
        """
        if self.mode_switch_cooldown > 0:
            self.mode_switch_cooldown -= 1
            
        if self.current_mode == OptionMode.DRIVING:
            if self.should_switch_to_manipulator(state):
                self.current_mode = OptionMode.MANIPULATOR
                self.mode_switch_cooldown = self.cooldown_frames
                
        elif self.current_mode == OptionMode.MANIPULATOR:
            if self.should_switch_to_driving(state):
                self.current_mode = OptionMode.DRIVING  
                self.mode_switch_cooldown = self.cooldown_frames
                
        return self.current_mode
        
    def get_current_mode(self) -> OptionMode:
        return self.current_mode
        
    def get_proximity_weight(self, state: Dict[str, float]) -> float:
        """
        Compute proximity weight w for option selection
        w = sigmoid((d_free_threshold - d_free) / scale)
        """
        d_free = state["lidar_front"]
        scale = 0.1  # sensitivity parameter
        
        x = (self.d_free_threshold - d_free) / scale
        return 1.0 / (1.0 + np.exp(-x))  # sigmoid
        
    def get_confidence_weight(self, state: Dict[str, float]) -> float:
        """
        Compute confidence weight based on lane detection quality q
        """
        q = state["lane_confidence"]
        return max(0.0, (q - 0.5) / 0.5)  # linear scaling from 0.5 to 1.0