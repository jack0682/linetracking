#!/usr/bin/env python3

import numpy as np
from typing import Dict, Any, Tuple
from sensor_msgs.msg import LaserScan

class LidarProcessor:
    def __init__(self, params: Dict[str, Any]):
        self.lidar_params = params["sensors"]["lidar"]["properties"]
        self.track_params = params["track"]["safety_margins"]
        
        # Angle sectors for distance computation
        self.front_sector = (-np.pi/6, np.pi/6)    # ±30° front
        self.left_sector = (np.pi/6, np.pi/2)      # 30° to 90° left  
        self.right_sector = (-np.pi/2, -np.pi/6)   # -90° to -30° right
        
    def process_scan(self, scan: LaserScan) -> Dict[str, float]:
        """
        Process lidar scan and return d_L, d_R, d_free
        """
        ranges = np.array(scan.ranges)
        angles = self._compute_angles(scan)
        
        # Filter invalid readings
        valid_mask = np.isfinite(ranges) & (ranges >= scan.range_min) & (ranges <= scan.range_max)
        ranges = np.where(valid_mask, ranges, scan.range_max)
        
        d_left = self._compute_sector_distance(ranges, angles, self.left_sector)
        d_right = self._compute_sector_distance(ranges, angles, self.right_sector) 
        d_free = self._compute_sector_distance(ranges, angles, self.front_sector)
        
        return {
            "lidar_left": d_left,
            "lidar_right": d_right, 
            "lidar_front": d_free
        }
        
    def _compute_angles(self, scan: LaserScan) -> np.ndarray:
        """Compute angle for each laser beam"""
        num_readings = len(scan.ranges)
        angles = scan.angle_min + np.arange(num_readings) * scan.angle_increment
        return angles
        
    def _compute_sector_distance(self, ranges: np.ndarray, angles: np.ndarray, 
                                sector: Tuple[float, float]) -> float:
        """Compute minimum distance in angular sector"""
        angle_min, angle_max = sector
        
        # Handle angle wraparound for right sector
        if angle_min < 0 and angle_max < 0:
            sector_mask = (angles >= angle_min) & (angles <= angle_max)
        else:
            sector_mask = (angles >= angle_min) & (angles <= angle_max)
            
        if not np.any(sector_mask):
            return self.lidar_params["range_max"]
            
        sector_ranges = ranges[sector_mask]
        return np.min(sector_ranges)
        
    def compute_free_space_map(self, scan: LaserScan) -> np.ndarray:
        """
        Compute local free space map for navigation
        Returns binary occupancy grid (1=free, 0=occupied)
        """
        ranges = np.array(scan.ranges)
        angles = self._compute_angles(scan)
        
        # Create local grid (2m x 2m, 5cm resolution)
        grid_size = 40  # 2m / 0.05m
        grid = np.ones((grid_size, grid_size), dtype=np.uint8)
        
        # Robot at center
        robot_x, robot_y = grid_size // 2, grid_size // 2
        
        for i, (range_val, angle) in enumerate(zip(ranges, angles)):
            if np.isfinite(range_val) and range_val < self.lidar_params["range_max"]:
                # Convert to Cartesian coordinates  
                x = range_val * np.cos(angle)
                y = range_val * np.sin(angle)
                
                # Convert to grid coordinates
                grid_x = int(robot_x + x / 0.05)
                grid_y = int(robot_y + y / 0.05)
                
                if 0 <= grid_x < grid_size and 0 <= grid_y < grid_size:
                    grid[grid_y, grid_x] = 0  # Mark as occupied
                    
        return grid
        
    def detect_obstacles(self, scan: LaserScan) -> Dict[str, Any]:
        """Detect obstacles and their properties"""
        ranges = np.array(scan.ranges)
        angles = self._compute_angles(scan)
        
        # Find obstacle clusters
        obstacle_threshold = 1.0  # meters
        obstacle_mask = ranges < obstacle_threshold
        
        if not np.any(obstacle_mask):
            return {"obstacles": [], "closest_distance": self.lidar_params["range_max"]}
            
        obstacles = []
        obstacle_ranges = ranges[obstacle_mask]
        obstacle_angles = angles[obstacle_mask]
        
        # Simple clustering (group consecutive readings)
        clusters = self._cluster_obstacles(obstacle_ranges, obstacle_angles)
        
        for cluster in clusters:
            avg_range = np.mean(cluster["ranges"])
            avg_angle = np.mean(cluster["angles"])
            
            obstacles.append({
                "distance": avg_range,
                "angle": avg_angle,
                "size": len(cluster["ranges"]),
                "x": avg_range * np.cos(avg_angle),
                "y": avg_range * np.sin(avg_angle)
            })
            
        closest_distance = min(obs["distance"] for obs in obstacles)
        
        return {"obstacles": obstacles, "closest_distance": closest_distance}
        
    def _cluster_obstacles(self, ranges: np.ndarray, angles: np.ndarray) -> list:
        """Simple obstacle clustering"""
        if len(ranges) == 0:
            return []
            
        clusters = []
        current_cluster = {"ranges": [ranges[0]], "angles": [angles[0]]}
        
        for i in range(1, len(ranges)):
            # Check if consecutive angles (simple clustering)
            if abs(angles[i] - angles[i-1]) < 0.1:  # 0.1 rad threshold
                current_cluster["ranges"].append(ranges[i])
                current_cluster["angles"].append(angles[i])
            else:
                if len(current_cluster["ranges"]) > 3:  # Minimum cluster size
                    clusters.append(current_cluster)
                current_cluster = {"ranges": [ranges[i]], "angles": [angles[i]]}
                
        if len(current_cluster["ranges"]) > 3:
            clusters.append(current_cluster)
            
        return clusters