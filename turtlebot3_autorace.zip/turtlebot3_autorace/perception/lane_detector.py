#!/usr/bin/env python3

import cv2
import numpy as np
from typing import Dict, Any, Tuple, Optional

class LaneDetector:
    def __init__(self, params: Dict[str, Any]):
        self.track_params = params["track"]
        self.camera_params = params["sensors"]["camera"]
        
        # Perspective transform setup
        roi = self.track_params["roi"]["perspective_transform"]
        self.src_points = np.float32(roi["src_points"])
        self.dst_points = np.float32(roi["dst_points"])
        self.M = cv2.getPerspectiveTransform(self.src_points, self.dst_points)
        self.M_inv = cv2.getPerspectiveTransform(self.dst_points, self.src_points)
        
    def detect_lane_with_confidence(self, image: np.ndarray) -> Tuple[float, float, float]:
        """
        Detect lane and return (d, Δψ, q)
        d: lateral deviation (meters)
        Δψ: heading error (radians) 
        q: confidence score [0,1]
        """
        # Apply ROI
        roi_image = self._apply_roi(image)
        
        # Bird's eye view transform
        warped = cv2.warpPerspective(roi_image, self.M, (640, 480))
        
        # Lane detection pipeline
        lane_mask = self._detect_lane_mask(warped)
        left_fit, right_fit, confidence = self._fit_lane_polynomials(lane_mask)
        
        if confidence < 0.3:  # Low confidence fallback
            return 0.0, 0.0, confidence
            
        # Compute lateral deviation and heading error
        d, delta_psi = self._compute_lane_deviation(left_fit, right_fit, warped.shape)
        
        return d, delta_psi, confidence
        
    def _apply_roi(self, image: np.ndarray) -> np.ndarray:
        """Apply region of interest mask"""
        roi = self.track_params["roi"]["camera_roi"]
        h, w = image.shape[:2]
        
        y_min = int(roi["y_min"] * h)
        y_max = int(roi["y_max"] * h)
        x_min = int(roi["x_min"] * w)
        x_max = int(roi["x_max"] * w)
        
        mask = np.zeros((h, w), dtype=np.uint8)
        mask[y_min:y_max, x_min:x_max] = 255
        
        return cv2.bitwise_and(image, image, mask=mask)
        
    def _detect_lane_mask(self, image: np.ndarray) -> np.ndarray:
        """Detect lane boundaries using color and edge detection"""
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Gaussian blur for noise reduction
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Edge detection
        edges = cv2.Canny(blurred, 50, 150)
        
        # Color-based lane detection (white lines)
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        white_lower = np.array([0, 0, 200])
        white_upper = np.array([180, 30, 255])
        white_mask = cv2.inRange(hsv, white_lower, white_upper)
        
        # Combine edge and color detection
        combined_mask = cv2.bitwise_or(edges, white_mask)
        
        return combined_mask
        
    def _fit_lane_polynomials(self, lane_mask: np.ndarray) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], float]:
        """Fit polynomial to detected lane boundaries"""
        h, w = lane_mask.shape
        
        # Sliding window approach for lane detection
        histogram = np.sum(lane_mask[h//2:, :], axis=0)
        
        # Find peaks for left and right lanes
        midpoint = w // 2
        left_peak = np.argmax(histogram[:midpoint])
        right_peak = np.argmax(histogram[midpoint:]) + midpoint
        
        # Extract lane pixels
        left_pixels = self._extract_lane_pixels(lane_mask, left_peak, "left")
        right_pixels = self._extract_lane_pixels(lane_mask, right_peak, "right")
        
        confidence = self._compute_detection_confidence(left_pixels, right_pixels, w)
        
        if confidence < 0.3:
            return None, None, confidence
            
        # Fit 2nd order polynomials
        left_fit = np.polyfit(left_pixels[0], left_pixels[1], 2) if len(left_pixels[0]) > 50 else None
        right_fit = np.polyfit(right_pixels[0], right_pixels[1], 2) if len(right_pixels[0]) > 50 else None
        
        return left_fit, right_fit, confidence
        
    def _extract_lane_pixels(self, mask: np.ndarray, peak: int, side: str) -> Tuple[np.ndarray, np.ndarray]:
        """Extract pixels belonging to a lane using sliding windows"""
        h, w = mask.shape
        nwindows = 9
        window_height = h // nwindows
        margin = 50
        
        x_current = peak
        lane_x, lane_y = [], []
        
        for window in range(nwindows):
            y_low = h - (window + 1) * window_height
            y_high = h - window * window_height
            x_low = max(0, x_current - margin)
            x_high = min(w, x_current + margin)
            
            # Find pixels in window
            good_pixels = ((mask[y_low:y_high, x_low:x_high] > 0).nonzero())
            if len(good_pixels[0]) > 10:
                window_x = good_pixels[1] + x_low
                window_y = good_pixels[0] + y_low
                lane_x.extend(window_x)
                lane_y.extend(window_y)
                x_current = int(np.mean(window_x))
                
        return np.array(lane_y), np.array(lane_x)
        
    def _compute_detection_confidence(self, left_pixels: Tuple, right_pixels: Tuple, image_width: int) -> float:
        """Compute detection confidence q based on pixel density and lane separation"""
        left_count = len(left_pixels[0])
        right_count = len(right_pixels[0])
        
        # Pixel density confidence
        min_pixels = 100
        density_conf = min(1.0, (left_count + right_count) / (2 * min_pixels))
        
        # Lane separation confidence (should be approximately track width)
        if left_count > 10 and right_count > 10:
            left_x_mean = np.mean(left_pixels[1])
            right_x_mean = np.mean(right_pixels[1]) 
            separation = abs(right_x_mean - left_x_mean)
            expected_separation = image_width * 0.4  # approximately 40% of image width
            separation_conf = max(0.0, 1.0 - abs(separation - expected_separation) / expected_separation)
        else:
            separation_conf = 0.0
            
        return 0.7 * density_conf + 0.3 * separation_conf
        
    def _compute_lane_deviation(self, left_fit: Optional[np.ndarray], right_fit: Optional[np.ndarray], 
                               image_shape: Tuple[int, int]) -> Tuple[float, float]:
        """Compute lateral deviation d and heading error Δψ"""
        h, w = image_shape
        y_eval = h - 1  # bottom of image
        
        if left_fit is None and right_fit is None:
            return 0.0, 0.0
            
        # Compute lane center
        if left_fit is not None and right_fit is not None:
            left_x = left_fit[0] * y_eval**2 + left_fit[1] * y_eval + left_fit[2]
            right_x = right_fit[0] * y_eval**2 + right_fit[1] * y_eval + right_fit[2]
            lane_center = (left_x + right_x) / 2
        elif left_fit is not None:
            left_x = left_fit[0] * y_eval**2 + left_fit[1] * y_eval + left_fit[2]
            lane_center = left_x + self.track_params["geometry"]["lane_width"] * 0.5 / self._pixel_to_meter_ratio()
        else:  # right_fit only
            right_x = right_fit[0] * y_eval**2 + right_fit[1] * y_eval + right_fit[2]
            lane_center = right_x - self.track_params["geometry"]["lane_width"] * 0.5 / self._pixel_to_meter_ratio()
            
        # Convert to meters (assuming perspective transform calibration)
        vehicle_center = w / 2
        d = (vehicle_center - lane_center) * self._pixel_to_meter_ratio()
        
        # Compute heading error from polynomial derivative
        if left_fit is not None and right_fit is not None:
            # Use average of both lanes for heading
            left_slope = 2 * left_fit[0] * y_eval + left_fit[1]
            right_slope = 2 * right_fit[0] * y_eval + right_fit[1] 
            avg_slope = (left_slope + right_slope) / 2
        elif left_fit is not None:
            avg_slope = 2 * left_fit[0] * y_eval + left_fit[1]
        else:
            avg_slope = 2 * right_fit[0] * y_eval + right_fit[1]
            
        delta_psi = np.arctan(avg_slope * self._pixel_to_meter_ratio())
        
        return d, delta_psi
        
    def _pixel_to_meter_ratio(self) -> float:
        """Convert pixels to meters based on camera calibration"""
        # This should be calibrated based on actual camera setup
        # For now, assume bird's eye view gives approximately this ratio
        return 0.001  # 1 pixel ≈ 1mm (to be calibrated)