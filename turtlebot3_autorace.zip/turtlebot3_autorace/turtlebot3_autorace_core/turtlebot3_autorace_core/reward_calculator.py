#!/usr/bin/env python3

import numpy as np
from typing import Dict, Any

class RewardCalculator:
    def __init__(self, params: Dict[str, Any]):
        self.track_params = params["track"]["safety_margins"]
        
        # Reward weights - scaled and unit-matched per your specification
        self.w_d = 1.0      # lateral deviation weight
        self.w_psi = 1.0    # heading error weight  
        self.w_v = 1.0      # velocity reward weight
        self.w_jerk = 0.1   # jerk penalty weight
        
        # Penalty constants: C_c ≫ C_l ≫ 1
        self.C_collision = 100.0  # collision penalty
        self.C_offlane = 10.0     # off-lane penalty
        
        # Normalization constants for unit matching
        self.d_max = self.track_params["d_max"]  # 0.18m
        self.angle_15_deg = np.radians(15)  # 15° reference
        self.v_max = 0.25  # m/s
        
        self.prev_action = np.array([0.0, 0.0])
        
    def compute_reward(self, state: Dict[str, float], action: np.ndarray, 
                      collision: bool = False, off_lane: bool = False) -> float:
        """
        Compute reward: R = -w_d*|d|/0.2 - w_ψ*(1-cos(Δψ))/(1-cos(15°)) + w_v*v/0.25 
                           - w_j*(Δv² + Δω²) - 1_offlane*C_l - 1_collision*C_c
        """
        d = abs(state["lateral_deviation"])
        heading_error = state["heading_error"]  
        v = state["linear_velocity"]
        
        # Unit-normalized terms
        lateral_penalty = -(self.w_d * d / 0.2)
        
        heading_penalty = -(self.w_psi * (1 - np.cos(heading_error)) / 
                           (1 - np.cos(self.angle_15_deg)))
                           
        velocity_reward = self.w_v * v / self.v_max
        
        # Jerk penalty (L2 norm of action difference)
        action_diff = action - self.prev_action
        jerk_penalty = -self.w_jerk * np.sum(action_diff ** 2)
        self.prev_action = action.copy()
        
        # Binary penalties
        off_lane_penalty = -self.C_offlane if off_lane else 0.0
        collision_penalty = -self.C_collision if collision else 0.0
        
        total_reward = (lateral_penalty + heading_penalty + velocity_reward + 
                       jerk_penalty + off_lane_penalty + collision_penalty)
                       
        return total_reward
        
    def compute_shaped_reward(self, state: Dict[str, float], action: np.ndarray) -> Dict[str, float]:
        """
        Return detailed reward components for analysis
        """
        d = abs(state["lateral_deviation"])
        heading_error = state["heading_error"]
        v = state["linear_velocity"]
        
        components = {
            "lateral": -(self.w_d * d / 0.2),
            "heading": -(self.w_psi * (1 - np.cos(heading_error)) / (1 - np.cos(self.angle_15_deg))),
            "velocity": self.w_v * v / self.v_max,
            "jerk": -self.w_jerk * np.sum((action - self.prev_action) ** 2)
        }
        
        components["total"] = sum(components.values())
        self.prev_action = action.copy()
        
        return components
        
    def is_off_lane(self, state: Dict[str, float]) -> bool:
        """Check if robot is off the lane"""
        return abs(state["lateral_deviation"]) > self.d_max
        
    def is_collision_imminent(self, state: Dict[str, float]) -> bool:
        """Check if collision is imminent""" 
        return state["lidar_front"] < self.track_params["d_free_critical"]
        
    def reset(self):
        """Reset internal state for new episode"""
        self.prev_action = np.array([0.0, 0.0])