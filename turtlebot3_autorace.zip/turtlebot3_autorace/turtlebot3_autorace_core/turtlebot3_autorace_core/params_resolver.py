#!/usr/bin/env python3

import yaml
import json
import hashlib
from pathlib import Path
from typing import Dict, Any
import jsonschema
from datetime import datetime

class ParamsResolver:
    def __init__(self, config_dir: str = "config", schema_dir: str = "schema"):
        self.config_dir = Path(config_dir)
        self.schema_dir = Path(schema_dir)
        
    def load_and_validate_yaml(self, yaml_file: str, schema_file: str) -> Dict[str, Any]:
        yaml_path = self.config_dir / yaml_file
        schema_path = self.schema_dir / schema_file
        
        if not yaml_path.exists():
            raise FileNotFoundError(f"Config file not found: {yaml_path}")
        if not schema_path.exists():
            raise FileNotFoundError(f"Schema file not found: {schema_path}")
            
        with open(yaml_path, 'r') as f:
            data = yaml.safe_load(f)
            
        with open(schema_path, 'r') as f:
            schema = json.load(f)
            
        jsonschema.validate(data, schema)
        return data
        
    def merge_configs(self) -> Dict[str, Any]:
        vehicle_config = self.load_and_validate_yaml("vehicle.yaml", "vehicle.schema.json")
        sensors_config = self.load_and_validate_yaml("sensors.yaml", "sensors.schema.json") 
        track_config = self.load_and_validate_yaml("track.yaml", "track.schema.json")
        
        merged = {
            **vehicle_config,
            **sensors_config, 
            **track_config,
            "timestamp": datetime.now().isoformat(),
        }
        
        return merged
        
    def compute_params_hash(self, params: Dict[str, Any]) -> str:
        params_copy = params.copy()
        if 'timestamp' in params_copy:
            del params_copy['timestamp']
            
        params_str = json.dumps(params_copy, sort_keys=True)
        return hashlib.sha256(params_str.encode()).hexdigest()[:12]
        
    def create_runtime_snapshot(self, output_path: str = "run_params.json") -> tuple[Dict[str, Any], str]:
        params = self.merge_configs()
        params_hash = self.compute_params_hash(params)
        
        params["config_hash"] = params_hash
        
        output_file = Path(output_path)
        with open(output_file, 'w') as f:
            json.dump(params, f, indent=2)
            
        return params, params_hash
        
    @staticmethod
    def get_state_normalization_params(params: Dict[str, Any]) -> Dict[str, Any]:
        track = params["track"]["safety_margins"]
        vehicle = params["vehicle"]["kinematics"]
        
        return {
            "d_range": [-track["d_max"], track["d_max"]],              # lateral deviation
            "sin_cos_range": [-1.0, 1.0],                             # sin/cos Δψ 
            "lidar_range": [0.0, params["sensors"]["lidar"]["properties"]["range_max"]],
            "velocity_range": [vehicle["min_linear_velocity"], vehicle["max_linear_velocity"]],
            "angular_range": [vehicle["min_angular_velocity"], vehicle["max_angular_velocity"]]
        }
        
    @staticmethod  
    def get_action_bounds(params: Dict[str, Any]) -> Dict[str, tuple]:
        vehicle = params["vehicle"]["kinematics"]
        return {
            "linear_velocity": (0.0, 0.25),      # m/s
            "angular_velocity": (-1.2, 1.2)      # rad/s  
        }
        
    @staticmethod
    def get_safety_thresholds(params: Dict[str, Any]) -> Dict[str, float]:
        margins = params["track"]["safety_margins"] 
        detection = params["track"]["detection"]
        
        return {
            "d_max": margins["d_max"],
            "d_min": margins["d_min"], 
            "d_free_min": margins["d_free_min"],
            "d_free_critical": margins["d_free_critical"],
            "lane_confidence_threshold": detection["lane_confidence_threshold"],
            "option_switch_threshold": 0.5,  # d_free < 0.5m for manipulator mode
            "min_confidence_for_switch": 0.7  # q > q0 for option switch
        }

if __name__ == "__main__":
    resolver = ParamsResolver()
    params, params_hash = resolver.create_runtime_snapshot()
    print(f"Runtime params created with hash: {params_hash}")
    print(f"State normalization: {resolver.get_state_normalization_params(params)}")
    print(f"Action bounds: {resolver.get_action_bounds(params)}")
    print(f"Safety thresholds: {resolver.get_safety_thresholds(params)}")