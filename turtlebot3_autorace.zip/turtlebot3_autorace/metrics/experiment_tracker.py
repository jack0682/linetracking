#!/usr/bin/env python3

import json
import numpy as np
from typing import Dict, Any, List
from pathlib import Path
from datetime import datetime
import subprocess

class ExperimentTracker:
    def __init__(self, experiment_config: Dict[str, Any], config_hash: str):
        self.experiment_config = experiment_config
        self.config_hash = config_hash
        self.experiment_name = experiment_config["experiment"]["name"]
        
        # Create experiment directory
        self.experiment_dir = Path("experiments") / f"{self.experiment_name}_{config_hash}"
        self.experiment_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize tracking
        self.start_time = datetime.now()
        self.training_metrics = []
        self.evaluation_metrics = []
        self.git_commit = self._get_git_commit_hash()
        
        # Save experiment configuration
        self._save_experiment_config()
        
    def _get_git_commit_hash(self) -> str:
        """Get current git commit hash for reproducibility"""
        try:
            result = subprocess.run(["git", "rev-parse", "HEAD"], 
                                 capture_output=True, text=True, check=True)
            return result.stdout.strip()
        except:
            return "unknown"
            
    def _save_experiment_config(self):
        """Save complete experiment configuration"""
        config_bundle = {
            "experiment_config": self.experiment_config,
            "config_hash": self.config_hash,
            "git_commit": self.git_commit,
            "start_time": self.start_time.isoformat(),
            "environment": {
                "python_version": subprocess.run(["python", "--version"], 
                                               capture_output=True, text=True).stdout.strip(),
                "ros_distro": subprocess.run(["printenv", "ROS_DISTRO"], 
                                           capture_output=True, text=True).stdout.strip()
            }
        }
        
        config_path = self.experiment_dir / "experiment_config.json"
        with open(config_path, 'w') as f:
            json.dump(config_bundle, f, indent=2)
            
    def log_training_step(self, step: int, metrics: Dict[str, float]):
        """Log training metrics"""
        self.training_metrics.append({
            "step": step,
            "timestamp": datetime.now().isoformat(),
            **metrics
        })
        
        # Save periodically
        if step % 1000 == 0:
            self._save_training_log()
            
    def log_evaluation_episode(self, episode: int, metrics: Dict[str, float]):
        """Log evaluation metrics"""
        self.evaluation_metrics.append({
            "episode": episode,
            "timestamp": datetime.now().isoformat(),
            **metrics
        })
        
        self._save_evaluation_log()
        
    def _save_training_log(self):
        """Save training metrics to file"""
        training_path = self.experiment_dir / "training_metrics.json"
        with open(training_path, 'w') as f:
            json.dump(self.training_metrics, f, indent=2)
            
    def _save_evaluation_log(self):
        """Save evaluation metrics to file"""
        eval_path = self.experiment_dir / "evaluation_metrics.json"  
        with open(eval_path, 'w') as f:
            json.dump(self.evaluation_metrics, f, indent=2)
            
    def save_model_checkpoint(self, model_state: Any, step: int) -> str:
        """Save model checkpoint with metadata"""
        checkpoint_dir = self.experiment_dir / "checkpoints"
        checkpoint_dir.mkdir(exist_ok=True)
        
        checkpoint_name = f"model_step_{step}_{self.config_hash}.pth"
        checkpoint_path = checkpoint_dir / checkpoint_name
        
        # Save model (implementation depends on framework - PyTorch example)
        try:
            import torch
            torch.save({
                "model_state_dict": model_state,
                "step": step,
                "config_hash": self.config_hash,
                "git_commit": self.git_commit,
                "timestamp": datetime.now().isoformat()
            }, checkpoint_path)
        except ImportError:
            # Fallback for other frameworks
            with open(checkpoint_path.with_suffix('.json'), 'w') as f:
                json.dump({
                    "step": step,
                    "config_hash": self.config_hash,
                    "git_commit": self.git_commit,
                    "timestamp": datetime.now().isoformat(),
                    "note": "Model state not saved - framework not detected"
                }, f, indent=2)
                
        return str(checkpoint_path)
        
    def create_experiment_bundle(self) -> str:
        """Create complete experiment bundle for reproduction"""
        end_time = datetime.now()
        
        # Compute final summary statistics
        summary_stats = self._compute_final_statistics()
        
        bundle = {
            "experiment_metadata": {
                "name": self.experiment_name,
                "config_hash": self.config_hash,
                "git_commit": self.git_commit,
                "start_time": self.start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration_hours": (end_time - self.start_time).total_seconds() / 3600
            },
            "performance_summary": summary_stats,
            "files": {
                "experiment_config": "experiment_config.json",
                "training_metrics": "training_metrics.json", 
                "evaluation_metrics": "evaluation_metrics.json",
                "model_checkpoints": "checkpoints/",
                "config_snapshot": f"../run_params_{self.config_hash}.json"
            },
            "reproducibility": {
                "command": f"python train.py --config-hash {self.config_hash} --git-commit {self.git_commit}",
                "requirements": "requirements.txt",
                "docker_image": f"turtlebot3-autorace:{self.git_commit[:8]}"
            }
        }
        
        bundle_path = self.experiment_dir / "EXPERIMENT_BUNDLE.json"
        with open(bundle_path, 'w') as f:
            json.dump(bundle, f, indent=2)
            
        return str(bundle_path)
        
    def _compute_final_statistics(self) -> Dict[str, float]:
        """Compute final performance statistics"""
        if not self.evaluation_metrics:
            return {}
            
        # Extract key metrics
        lane_deviations = [ep["lane_deviation_rms"] for ep in self.evaluation_metrics]
        collision_rates = [ep["collision_count"] for ep in self.evaluation_metrics] 
        completion_rates = [ep["completion_rate"] for ep in self.evaluation_metrics]
        
        return {
            "final_lane_deviation_mean": np.mean(lane_deviations),
            "final_collision_rate": np.mean(collision_rates),
            "final_completion_rate": np.mean(completion_rates),
            "success_rate": np.mean([cr > 0.95 for cr in completion_rates]),  # 95% completion = success
            "total_episodes": len(self.evaluation_metrics)
        }