#!/usr/bin/env python3

import numpy as np
from typing import Dict, Any
from pathlib import Path

try:
    from torch.utils.tensorboard import SummaryWriter
    TENSORBOARD_AVAILABLE = True
except ImportError:
    TENSORBOARD_AVAILABLE = False
    
class TensorBoardLogger:
    def __init__(self, log_dir: str, config_hash: str, experiment_name: str):
        if not TENSORBOARD_AVAILABLE:
            print("Warning: TensorBoard not available. Logging to console only.")
            self.writer = None
            return
            
        self.log_dir = Path(log_dir) / f"{experiment_name}_{config_hash}"
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.writer = SummaryWriter(str(self.log_dir))
        self.step_count = 0
        
    def log_step(self, metrics: Dict[str, float], global_step: int = None):
        """Log metrics for a single step"""
        if not self.writer:
            return
            
        step = global_step if global_step is not None else self.step_count
        
        # Core state metrics
        if "lateral_deviation" in metrics:
            self.writer.add_scalar("State/LateralDeviation", metrics["lateral_deviation"], step)
        if "heading_error" in metrics:
            self.writer.add_scalar("State/HeadingError", np.degrees(metrics["heading_error"]), step)
        if "lane_confidence" in metrics:
            self.writer.add_scalar("State/LaneConfidence", metrics["lane_confidence"], step)
            
        # Lidar metrics
        for key in ["lidar_front", "lidar_left", "lidar_right"]:
            if key in metrics:
                self.writer.add_scalar(f"Lidar/{key.replace('lidar_', '').title()}", metrics[key], step)
                
        # Control metrics
        if "linear_velocity" in metrics:
            self.writer.add_scalar("Control/LinearVelocity", metrics["linear_velocity"], step)
        if "angular_velocity" in metrics:
            self.writer.add_scalar("Control/AngularVelocity", metrics["angular_velocity"], step)
            
        self.step_count += 1
        
    def log_episode(self, episode_metrics: Dict[str, float], episode: int):
        """Log episode-level metrics"""
        if not self.writer:
            return
            
        # Performance metrics
        self.writer.add_scalar("Episode/LaneDeviationRMS", episode_metrics.get("lane_deviation_rms", 0), episode)
        self.writer.add_scalar("Episode/CollisionCount", episode_metrics.get("collision_count", 0), episode)
        self.writer.add_scalar("Episode/OffLaneCount", episode_metrics.get("off_lane_count", 0), episode)
        self.writer.add_scalar("Episode/CompletionRate", episode_metrics.get("completion_rate", 0), episode)
        
        # Control quality
        self.writer.add_scalar("Episode/SteeringVariance", episode_metrics.get("steering_variance", 0), episode)
        self.writer.add_scalar("Episode/AverageSpeed", episode_metrics.get("average_speed", 0), episode)
        
        # Safety metrics
        self.writer.add_scalar("Episode/SafetyInterventions", episode_metrics.get("safety_interventions", 0), episode)
        
    def log_reward_components(self, reward_components: Dict[str, float], step: int):
        """Log detailed reward breakdown"""
        if not self.writer:
            return
            
        for component, value in reward_components.items():
            self.writer.add_scalar(f"Reward/{component.title()}", value, step)
            
    def log_safety_events(self, cbf_values: Dict[str, float], step: int):
        """Log CBF barrier function values"""
        if not self.writer:
            return
            
        for barrier_name, value in cbf_values.items():
            self.writer.add_scalar(f"Safety/CBF_{barrier_name}", value, step)
            
    def log_option_selection(self, option_weights: Dict[str, float], current_option: str, step: int):
        """Log HRL option selection data"""
        if not self.writer:
            return
            
        self.writer.add_scalar("HRL/CurrentOption", 1.0 if current_option == "manipulator" else 0.0, step)
        
        for weight_name, value in option_weights.items():
            self.writer.add_scalar(f"HRL/{weight_name.title()}", value, step)
            
    def log_hyperparameters(self, hparams: Dict[str, Any], metrics: Dict[str, float]):
        """Log hyperparameters and final metrics"""
        if not self.writer:
            return
            
        # Flatten nested config for tensorboard
        flat_hparams = self._flatten_dict(hparams)
        self.writer.add_hparams(flat_hparams, metrics)
        
    def _flatten_dict(self, d: Dict[str, Any], parent_key: str = '', sep: str = '/') -> Dict[str, Any]:
        """Flatten nested dictionary for tensorboard hparams"""
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(self._flatten_dict(v, new_key, sep=sep).items())
            elif isinstance(v, (int, float, str, bool)):
                items.append((new_key, v))
        return dict(items)
        
    def close(self):
        """Close tensorboard writer"""
        if self.writer:
            self.writer.close()