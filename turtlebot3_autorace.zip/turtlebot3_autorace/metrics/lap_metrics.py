#!/usr/bin/env python3

import csv
import numpy as np
from typing import Dict, Any, List
from pathlib import Path
from datetime import datetime
import json

class LapMetrics:
    def __init__(self, config_hash: str, experiment_name: str, log_dir: str = "metrics_logs"):
        self.config_hash = config_hash
        self.experiment_name = experiment_name
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        
        # Current lap tracking
        self.current_lap = 0
        self.lap_start_time = None
        self.lap_data = []
        
        # Metrics accumulation
        self.episode_metrics = []
        
        # CSV file setup
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.csv_filename = f"{experiment_name}_{config_hash}_{timestamp}.csv"
        self.csv_path = self.log_dir / self.csv_filename
        
        self._initialize_csv()
        
    def _initialize_csv(self):
        """Initialize CSV file with headers"""
        headers = [
            "lap_id", "config_hash", "timestamp", 
            "lap_time", "completion_rate", "lane_deviation_rms", "lane_deviation_max",
            "collision_count", "off_lane_count", "off_lane_duration", 
            "steering_variance", "speed_mean", "speed_variance",
            "confidence_mean", "confidence_min", "safety_interventions",
            "total_distance", "average_speed"
        ]
        
        with open(self.csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            
    def start_lap(self):
        """Start tracking a new lap"""
        self.current_lap += 1
        self.lap_start_time = datetime.now()
        self.lap_data = []
        
    def record_step(self, state: Dict[str, float], action: np.ndarray, 
                   collision: bool = False, off_lane: bool = False,
                   safety_intervention: bool = False):
        """Record data for current timestep"""
        if self.lap_start_time is None:
            self.start_lap()
            
        step_data = {
            "timestamp": datetime.now().isoformat(),
            "lateral_deviation": state["lateral_deviation"],
            "heading_error": state["heading_error"], 
            "lane_confidence": state["lane_confidence"],
            "lidar_front": state["lidar_front"],
            "linear_velocity": state["linear_velocity"],
            "angular_velocity": state["angular_velocity"],
            "action_v": action[0],
            "action_omega": action[1],
            "collision": collision,
            "off_lane": off_lane,
            "safety_intervention": safety_intervention
        }
        
        self.lap_data.append(step_data)
        
    def finish_lap(self, completed: bool = True) -> Dict[str, float]:
        """Finish current lap and compute metrics"""
        if not self.lap_data:
            return {}
            
        lap_time = (datetime.now() - self.lap_start_time).total_seconds()
        
        # Convert to numpy arrays for efficient computation
        data_array = self._convert_to_arrays(self.lap_data)
        
        # Compute lap metrics
        metrics = {
            "lap_id": self.current_lap,
            "config_hash": self.config_hash,
            "timestamp": datetime.now().isoformat(),
            "lap_time": lap_time,
            "completion_rate": 1.0 if completed else len(self.lap_data) / 1000,  # assume 1000 steps = full lap
            
            # Lane following performance
            "lane_deviation_rms": np.sqrt(np.mean(data_array["lateral_deviation"] ** 2)),
            "lane_deviation_max": np.max(np.abs(data_array["lateral_deviation"])),
            
            # Safety metrics  
            "collision_count": np.sum(data_array["collision"]),
            "off_lane_count": np.sum(data_array["off_lane"]),
            "off_lane_duration": np.sum(data_array["off_lane"]) * 0.1,  # assuming 10Hz
            
            # Control smoothness
            "steering_variance": np.var(data_array["angular_velocity"]),
            "speed_mean": np.mean(data_array["linear_velocity"]),
            "speed_variance": np.var(data_array["linear_velocity"]),
            
            # Perception quality
            "confidence_mean": np.mean(data_array["lane_confidence"]),
            "confidence_min": np.min(data_array["lane_confidence"]),
            
            # Safety interventions
            "safety_interventions": np.sum(data_array["safety_intervention"]),
            
            # Performance metrics
            "total_distance": np.sum(data_array["linear_velocity"]) * 0.1,  # approximate
            "average_speed": np.mean(data_array["linear_velocity"])
        }
        
        # Save to CSV
        self._save_lap_to_csv(metrics)
        
        # Add to episode metrics
        self.episode_metrics.append(metrics)
        
        # Reset for next lap
        self.lap_data = []
        self.lap_start_time = None
        
        return metrics
        
    def _convert_to_arrays(self, lap_data: List[Dict]) -> Dict[str, np.ndarray]:
        """Convert list of dicts to dict of arrays for efficient computation"""
        arrays = {}
        for key in lap_data[0].keys():
            if key != "timestamp":  # Skip non-numeric data
                arrays[key] = np.array([step[key] for step in lap_data])
        return arrays
        
    def _save_lap_to_csv(self, metrics: Dict[str, float]):
        """Save lap metrics to CSV file"""
        with open(self.csv_path, 'a', newline='') as f:
            writer = csv.writer(f)
            row = [
                metrics["lap_id"], metrics["config_hash"], metrics["timestamp"],
                metrics["lap_time"], metrics["completion_rate"], 
                metrics["lane_deviation_rms"], metrics["lane_deviation_max"],
                metrics["collision_count"], metrics["off_lane_count"], metrics["off_lane_duration"],
                metrics["steering_variance"], metrics["speed_mean"], metrics["speed_variance"],
                metrics["confidence_mean"], metrics["confidence_min"], metrics["safety_interventions"],
                metrics["total_distance"], metrics["average_speed"]
            ]
            writer.writerow(row)
            
    def get_summary_statistics(self) -> Dict[str, float]:
        """Compute summary statistics across all completed laps"""
        if not self.episode_metrics:
            return {}
            
        metrics_array = {}
        for key in ["lane_deviation_rms", "collision_count", "steering_variance", "average_speed"]:
            values = [lap[key] for lap in self.episode_metrics]
            metrics_array[key] = {
                "mean": np.mean(values),
                "std": np.std(values), 
                "min": np.min(values),
                "max": np.max(values)
            }
            
        return metrics_array
        
    def save_experiment_bundle(self, model_checkpoint_path: str, git_commit_hash: str):
        """Save complete experiment bundle for reproducibility"""
        bundle = {
            "experiment_name": self.experiment_name,
            "config_hash": self.config_hash,
            "git_commit": git_commit_hash,
            "model_checkpoint": model_checkpoint_path,
            "csv_log": str(self.csv_path),
            "total_laps": self.current_lap,
            "summary_statistics": self.get_summary_statistics(),
            "timestamp": datetime.now().isoformat()
        }
        
        bundle_path = self.log_dir / f"experiment_bundle_{self.config_hash}.json"
        with open(bundle_path, 'w') as f:
            json.dump(bundle, f, indent=2)
            
        return str(bundle_path)