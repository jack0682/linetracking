#!/usr/bin/env python3

import numpy as np
from typing import Dict, Any
from collections import deque

class StateEstimator:
    def __init__(self, params: Dict[str, Any]):
        self.params = params
        self.smoothing_window = params["track"]["detection"]["smoothing_window"]
        
        # Temporal smoothing buffers
        self.d_buffer = deque(maxlen=self.smoothing_window)
        self.heading_buffer = deque(maxlen=self.smoothing_window) 
        self.confidence_buffer = deque(maxlen=self.smoothing_window)
        
        # State history for derivative computation
        self.prev_state = None
        self.dt = 0.1  # 10Hz assumption
        
    def update_state(self, perception_data: Dict[str, Any], vehicle_state: Dict[str, float]) -> Dict[str, float]:
        """
        Combine perception and vehicle data into normalized state vector
        """
        # Lane detection data
        d_raw = perception_data.get("lateral_deviation", 0.0)
        heading_error_raw = perception_data.get("heading_error", 0.0)
        confidence_raw = perception_data.get("lane_confidence", 0.0)
        
        # Apply temporal smoothing
        self.d_buffer.append(d_raw)
        self.heading_buffer.append(heading_error_raw)
        self.confidence_buffer.append(confidence_raw)
        
        d_smooth = np.mean(self.d_buffer) if self.d_buffer else d_raw
        heading_smooth = self._smooth_angle(list(self.heading_buffer)) if self.heading_buffer else heading_error_raw
        confidence_smooth = np.mean(self.confidence_buffer) if self.confidence_buffer else confidence_raw
        
        # Lidar data
        d_left = perception_data.get("lidar_left", 3.5)
        d_right = perception_data.get("lidar_right", 3.5)  
        d_free = perception_data.get("lidar_front", 3.5)
        
        # Vehicle kinematics
        v = vehicle_state.get("linear_velocity", 0.0)
        omega = vehicle_state.get("angular_velocity", 0.0)
        
        # Construct full state
        state = {
            "lateral_deviation": d_smooth,
            "heading_error": heading_smooth,
            "lane_confidence": confidence_smooth,
            "lidar_left": d_left,
            "lidar_right": d_right,
            "lidar_front": d_free,
            "linear_velocity": v,
            "angular_velocity": omega
        }
        
        # Add derivatives if previous state exists
        if self.prev_state is not None:
            state.update(self._compute_derivatives(state, self.prev_state))
            
        self.prev_state = state.copy()
        return state
        
    def _smooth_angle(self, angles: list) -> float:
        """Smooth angle sequence accounting for wraparound"""
        if not angles:
            return 0.0
            
        # Convert to complex numbers to handle wraparound
        complex_angles = [np.exp(1j * angle) for angle in angles]
        mean_complex = np.mean(complex_angles)
        return np.angle(mean_complex)
        
    def _compute_derivatives(self, current_state: Dict[str, float], 
                           prev_state: Dict[str, float]) -> Dict[str, float]:
        """Compute state derivatives for jerk penalty and dynamics"""
        derivatives = {}
        
        # Velocity derivatives (jerk)
        derivatives["linear_acceleration"] = (
            current_state["linear_velocity"] - prev_state["linear_velocity"]) / self.dt
        derivatives["angular_acceleration"] = (
            current_state["angular_velocity"] - prev_state["angular_velocity"]) / self.dt
            
        # Lane following derivatives
        derivatives["lateral_velocity"] = (
            current_state["lateral_deviation"] - prev_state["lateral_deviation"]) / self.dt
        derivatives["heading_rate"] = (
            current_state["heading_error"] - prev_state["heading_error"]) / self.dt
            
        return derivatives
        
    def get_normalized_state_vector(self, state: Dict[str, float], normalizer) -> np.ndarray:
        """Get normalized state vector for RL agent"""
        return normalizer.normalize_state(state)
        
    def is_state_valid(self, state: Dict[str, float]) -> bool:
        """Check if state is valid for control"""
        required_keys = ["lateral_deviation", "heading_error", "lane_confidence", 
                        "lidar_left", "lidar_right", "lidar_front", 
                        "linear_velocity", "angular_velocity"]
        
        return (all(key in state for key in required_keys) and
                all(np.isfinite(state[key]) for key in required_keys) and
                state["lane_confidence"] > 0.1)  # Minimum confidence threshold
                
    def predict_future_state(self, current_state: Dict[str, float], 
                            action: np.ndarray, horizon: float = 0.5) -> Dict[str, float]:
        """
        Predict future state for safety verification
        Simple kinematic model: assume constant action over horizon
        """
        v, omega = action
        
        # Simple bicycle model prediction
        dt = horizon
        
        predicted = current_state.copy()
        predicted["linear_velocity"] = v
        predicted["angular_velocity"] = omega
        
        # Update position based on current heading error and action
        delta_psi = current_state["heading_error"]
        
        # Lateral deviation dynamics: ḋ ≈ v * sin(Δψ + ω*dt)
        future_heading_error = delta_psi + omega * dt
        lateral_change = v * np.sin(future_heading_error) * dt
        predicted["lateral_deviation"] = current_state["lateral_deviation"] + lateral_change
        predicted["heading_error"] = future_heading_error
        
        # Simple forward motion prediction for lidar front
        forward_motion = v * np.cos(delta_psi) * dt
        predicted["lidar_front"] = max(0.0, current_state["lidar_front"] - forward_motion)
        
        return predicted