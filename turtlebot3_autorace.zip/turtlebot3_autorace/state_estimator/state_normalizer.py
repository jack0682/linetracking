#!/usr/bin/env python3

import numpy as np
from typing import Dict, Any, Tuple

class StateNormalizer:
    def __init__(self, params: Dict[str, Any]):
        self.norm_params = self._extract_normalization_params(params)
        
    def _extract_normalization_params(self, params: Dict[str, Any]) -> Dict[str, Tuple[float, float]]:
        track = params["track"]["safety_margins"]
        vehicle = params["vehicle"]["kinematics"] 
        lidar = params["sensors"]["lidar"]["properties"]
        
        return {
            "d": (-track["d_max"], track["d_max"]),
            "sin_cos": (-1.0, 1.0),
            "lidar_distances": (0.0, lidar["range_max"]),
            "velocity": (vehicle["min_linear_velocity"], vehicle["max_linear_velocity"]),
            "angular": (vehicle["min_angular_velocity"], vehicle["max_angular_velocity"])
        }
    
    def normalize_state(self, raw_state: Dict[str, float]) -> np.ndarray:
        """
        Normalize state s = [d, sin(Δψ), cos(Δψ), d_L, d_R, d_free, v, ω] to [-1, 1]
        """
        d = self._normalize_value(raw_state["lateral_deviation"], *self.norm_params["d"])
        
        # Angle normalization - preserve periodicity via sin/cos
        sin_heading_error = np.sin(raw_state["heading_error"])
        cos_heading_error = np.cos(raw_state["heading_error"])
        
        d_left = self._normalize_value(raw_state["lidar_left"], *self.norm_params["lidar_distances"])
        d_right = self._normalize_value(raw_state["lidar_right"], *self.norm_params["lidar_distances"])  
        d_free = self._normalize_value(raw_state["lidar_front"], *self.norm_params["lidar_distances"])
        
        v = self._normalize_value(raw_state["linear_velocity"], *self.norm_params["velocity"])
        omega = self._normalize_value(raw_state["angular_velocity"], *self.norm_params["angular"])
        
        return np.array([d, sin_heading_error, cos_heading_error, d_left, d_right, d_free, v, omega], dtype=np.float32)
    
    def _normalize_value(self, value: float, min_val: float, max_val: float) -> float:
        """Normalize value to [-1, 1] range"""
        return 2.0 * (value - min_val) / (max_val - min_val) - 1.0
        
    def denormalize_action(self, normalized_action: np.ndarray) -> Dict[str, float]:
        """
        Denormalize action from [-1, 1] to physical units
        """
        v_norm, omega_norm = normalized_action
        
        # Map [0, 1] to [0, 0.25] for velocity (forward only)
        v_norm_positive = (v_norm + 1.0) / 2.0  # [-1,1] -> [0,1]
        v = v_norm_positive * 0.25
        
        # Map [-1, 1] to [-1.2, 1.2] for angular velocity
        omega = omega_norm * 1.2
        
        return {"linear_velocity": v, "angular_velocity": omega}
        
    def get_action_bounds(self) -> Dict[str, Tuple[float, float]]:
        return {
            "linear_velocity": (0.0, 0.25),
            "angular_velocity": (-1.2, 1.2)
        }